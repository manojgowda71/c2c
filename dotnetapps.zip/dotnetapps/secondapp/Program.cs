﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World! for the c#");
Console.WriteLine("add these numbers:"+(5+5));
